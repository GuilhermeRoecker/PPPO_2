package atividade_banco.teste;

import org.junit.Test;

public class contaCorrenteTest {
    @Test
    public void testDeposito() {

    }

    @Test
    public void testGetNumeroConta() {

    }

    @Test
    public void testGetSaldo() {

    }

    @Test
    public void testSaque() {

    }

    @Test
    public void testSetNumeroConta() {

    }

    @Test
    public void testSetSaldo() {

    }

    @Test
    public void testToString() {

    }

    @Test
    public void testTransferencia() {

    }
}
