package Jogo_Pergunta_Respostas;

import java.util.ArrayList;

//Titulo
//respostas
//Constrtutor
//Gets/Sets
//toString

public class Pergunta {
    

}
