package atividade_banco;

public class contaCorrente extends contaBancaria {

    public contaCorrente(int numeroConta, double saldo) {
        super(numeroConta, saldo);
    }
    

}
