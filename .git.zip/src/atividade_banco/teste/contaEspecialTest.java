package atividade_banco.teste;

import org.junit.Test;

public class contaEspecialTest {





    
    @Test
    public void testGetLimite() {

    }

    @Test
    public void testSaque() {

    }

    @Test
    public void testSetLimite() {

    }

    @Test
    public void testToString() {

    }
}
